// MathJax configuration - Supports LaTeX and AsciiMath
window.MathJax = {
  tex: {
    inlineMath: [['$', '$'], ['\\(', '\\)']],
    displayMath: [['$$', '$$'], ['\\[', '\\]']],
    processEscapes: true,
    processEnvironments: true
  },
  asciimath: {
    delimiters: [['`', '`']]
  },
  options: {
    skipHtmlTags: ['script', 'noscript', 'style', 'textarea', 'pre', 'code'],
    ignoreHtmlClass: 'tex2jax_ignore',
    processHtmlClass: 'tex2jax_process'
  },
  loader: {
    load: ['input/asciimath', '[tex]/ams', '[tex]/mathtools']
  },
  tex: {
    packages: {'[+]': ['ams', 'mathtools']},
    inlineMath: [['$', '$'], ['\\(', '\\)']],
    displayMath: [['$$', '$$'], ['\\[', '\\]']],
    processEscapes: true,
    processEnvironments: true
  },
  startup: {
    pageReady: () => {
      return MathJax.startup.defaultPageReady().then(() => {
        console.log('MathJax loaded with LaTeX and AsciiMath support on Moodle page');
      });
    }
  }
};

// Function to inject MathJax
function injectMathJax() {
  // Check if MathJax is already loaded
  if (window.MathJax && window.MathJax.typesetPromise) {
    console.log('MathJax already loaded, re-rendering...');
    window.MathJax.typesetPromise();
    return;
  }

  // Create and inject MathJax script with support for both LaTeX and AsciiMath
  const script = document.createElement('script');
  script.id = 'MathJax-script';
  script.async = true;
  // Using tex-mml-chtml loads LaTeX, MathML, and CommonHTML output
  // For AsciiMath support, we use the full MathJax bundle
  script.src = 'https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js';

  script.onload = function() {
    console.log('MathJax successfully injected with LaTeX and AsciiMath support');
  };

  script.onerror = function() {
    console.error('Failed to load MathJax');
  };

  document.head.appendChild(script);
}

// Inject MathJax when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectMathJax);
} else {
  injectMathJax();
}

// Observer to re-render MathJax when content changes (for AJAX-loaded content)
const observer = new MutationObserver((mutations) => {
  if (window.MathJax && window.MathJax.typesetPromise) {
    // Debounce the typeset calls
    clearTimeout(window.mathJaxTimeout);
    window.mathJaxTimeout = setTimeout(() => {
      window.MathJax.typesetPromise().catch((err) => console.error('MathJax rendering error:', err));
    }, 500);
  }
});

// Start observing the document for changes
observer.observe(document.body, {
  childList: true,
  subtree: true
});
