# Quick Start - Ready to Distribute!

## ✅ Your extension is ready!

The folder `moodle-mathjax-extension` contains everything needed.

## Before You Distribute

### 1. Test It Yourself First

1. Open Chrome/Edge
2. Go to `chrome://extensions/`
3. Enable "Developer mode" (top-right)
4. Click "Load unpacked"
5. Select the `moodle-mathjax-extension` folder
6. Visit your Moodle site and test with: `$x^2 + y^2 = z^2$`

### 2. Customize for Your Moodle Site (Optional but Recommended)

Edit `manifest.json` line 7-13 to match your specific Moodle URL:

**Example:** If your Moodle is at `https://learn.myschool.edu/`

Change:
```json
"matches": [
  "*://*.moodle.com/*",
  "*://*/moodle/*",
  ...
]
```

To:
```json
"matches": [
  "https://learn.myschool.edu/*"
]
```

This makes the extension only work on your school's Moodle (more secure).

## How to Distribute

### Option 1: ZIP File (Easiest)

1. Right-click the `moodle-mathjax-extension` folder
2. Select "Send to" → "Compressed (zipped) folder"
3. Upload the ZIP to your LMS or email to students
4. Share the `README.md` with installation instructions

### Option 2: Google Drive / OneDrive

1. Upload the entire folder to your cloud drive
2. Share the link with students
3. Students download and follow `README.md`

### Option 3: Chrome Web Store (Most Professional)

See `INSTRUCTOR_GUIDE.md` for full details. Requires:
- $5 one-time fee
- 2-3 days review time
- Students can install with one click

## What Students Need to Do

**Super simple - 3 steps:**

1. Extract the ZIP file
2. In Chrome, go to `chrome://extensions/`, enable Developer Mode, click "Load unpacked"
3. Select the folder - Done!

Full instructions are in `README.md` (give this to students).

## Files Included

```
moodle-mathjax-extension/
├── manifest.json          # Extension configuration
├── content.js             # Main script that injects MathJax
├── popup.html             # Info popup when clicking extension icon
├── icon16.png            # Small icon
├── icon48.png            # Medium icon
├── icon128.png           # Large icon
├── README.md             # Student installation guide
├── INSTRUCTOR_GUIDE.md   # Detailed guide for you
└── QUICK_START.md        # This file
```

## Troubleshooting

**Extension not loading?**
- Make sure Developer Mode is ON
- Verify folder contains `manifest.json`
- Try restarting browser

**Math not rendering?**
- Refresh the Moodle page (F5)
- Check browser console (F12) for errors
- Verify you're on a Moodle page matching the URLs in manifest.json

## Need Help?

Check `INSTRUCTOR_GUIDE.md` for:
- Detailed customization options
- Common student issues and solutions
- How to publish to Chrome Web Store
- Advanced MathJax configuration

---

**That's it! You're ready to distribute.** 🎉
