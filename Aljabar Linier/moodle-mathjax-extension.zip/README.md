# Moodle MathJax Enabler - Installation Guide for Students

This browser extension automatically enables mathematical notation rendering on Moodle pages using MathJax with support for both **LaTeX** and **AsciiMath**.

## Installation Instructions

### For Chrome / Edge / Brave

1. **Download the extension**
   - Extract the ZIP file to a folder (e.g., `moodle-mathjax-extension`)
   - Remember this location!

2. **Open Extension Settings**
   - Open your browser
   - Go to: `chrome://extensions/` (or `edge://extensions/` for Edge)
   - Or click the puzzle icon → "Manage Extensions"

3. **Enable Developer Mode**
   - Toggle "Developer mode" ON (top-right corner)

4. **Load the Extension**
   - Click "Load unpacked"
   - Select the `moodle-mathjax-extension` folder
   - Click "Select Folder"

5. **Verify Installation**
   - You should see "Moodle MathJax Enabler" in your extensions list
   - The extension is now active!

### For Firefox

1. **Download the extension**
   - Extract the ZIP file to a folder

2. **Open Add-ons**
   - Go to: `about:debugging#/runtime/this-firefox`

3. **Load Temporary Add-on**
   - Click "Load Temporary Add-on"
   - Select the `manifest.json` file from the extension folder

**Note for Firefox:** This will be temporary and needs to be reloaded each browser session. For permanent installation, the extension needs to be signed by Mozilla.

## Updating the Extension

If your instructor provides an updated version:
1. Download the new version
2. In `chrome://extensions/`, click "Remove" on the old version
3. Follow installation steps again with the new folder

## Troubleshooting

**Math formulas not showing?**
- Refresh the Moodle page (F5)
- Make sure the extension is enabled in `chrome://extensions/`
- Check that you're on a Moodle page

**Extension not appearing?**
- Make sure Developer Mode is ON
- Try restarting your browser
- Verify the folder contains `manifest.json`

## How to Use

Once installed, the extension works automatically! Just visit your Moodle site and mathematical notation will render properly.

### Supported Formats:

**LaTeX (recommended for complex math):**
- Inline: `$x^2 + y^2$` → displays as formatted math
- Display: `$$\int_0^1 f(x)dx$$` → centered equation
- Alternative: `\(formula\)` or `\[formula\]`

**AsciiMath (simpler syntax):**
- Use backticks: `` `x^2 + y^2` `` → displays as formatted math
- Examples: `` `sum_(i=1)^n i` ``, `` `int_0^1 x^2 dx` ``
- Fractions: `` `a/b` `` → displays as a fraction

### Quick Examples:

| You Type | What You See |
|----------|--------------|
| `$x^2 + y^2 = z^2$` | x² + y² = z² (formatted) |
| `$$\frac{a}{b}$$` | a/b as a proper fraction (centered) |
| `` `sqrt(2)` `` | √2 (formatted) |
| `` `sum_(i=1)^n i = (n(n+1))/2` `` | Summation formula (formatted) |

## Testing the Extension

Open `test-page.html` (included with the extension) in your browser to test if everything is working correctly.

## Uninstalling

1. Go to `chrome://extensions/`
2. Find "Moodle MathJax Enabler"
3. Click "Remove"
