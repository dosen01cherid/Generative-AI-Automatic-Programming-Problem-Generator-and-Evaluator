# Changelog

## Version 1.1 - AsciiMath Support Added

### New Features
- ✨ **AsciiMath Support**: Extension now supports AsciiMath notation in addition to LaTeX
- 🔧 **Enhanced Configuration**: MathJax configuration updated to load AsciiMath input processor
- 📦 **Additional Packages**: Added AMS and mathtools packages for extended LaTeX support

### AsciiMath Delimiters
- Use backticks for AsciiMath: `` `x^2 + y^2 = z^2` ``
- Much simpler syntax than LaTeX for basic formulas

### AsciiMath Examples
- Fractions: `` `a/b` `` or `` `(a+b)/(c+d)` ``
- Roots: `` `sqrt(2)` `` or `` `root(3)(8)` ``
- Summation: `` `sum_(i=1)^n i` ``
- Integration: `` `int_0^1 x^2 dx` ``
- Limits: `` `lim_(x->oo) 1/x` ``
- Matrices: `` `[[a,b],[c,d]]` ``
- Greek letters: `` `alpha + beta = gamma` ``

### Updated Files
- `content.js` - Added AsciiMath configuration and loader
- `popup.html` - Added AsciiMath examples
- `test-page.html` - Comprehensive tests for both LaTeX and AsciiMath
- `README.md` - Documentation updated with AsciiMath usage
- `manifest.json` - Version bumped to 1.1, description updated

### Why AsciiMath?
AsciiMath provides a simpler, more intuitive syntax for students who find LaTeX complex:
- **LaTeX**: `$$\frac{a}{b}$$` or `$$\sum_{i=1}^{n} i$$`
- **AsciiMath**: `` `a/b` `` or `` `sum_(i=1)^n i` ``

Both formats work simultaneously - use whichever you prefer!

---

## Version 1.0 - Initial Release

### Features
- LaTeX support with standard delimiters
- Automatic injection on Moodle pages
- Support for inline and display math
- MutationObserver for AJAX content
- Browser extension icons
- Comprehensive documentation

### LaTeX Delimiters
- Inline: `$...$` or `\(...\)`
- Display: `$$...$$` or `\[...\]`
