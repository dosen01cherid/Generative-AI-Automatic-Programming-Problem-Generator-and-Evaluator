#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Create simple placeholder icons for the browser extension"""

from PIL import Image, ImageDraw, ImageFont
import os

def create_icon(size, filename):
    """Create a simple icon with a math symbol"""
    # Create image with blue background
    img = Image.new('RGB', (size, size), color='#2196F3')
    draw = ImageDraw.Draw(img)

    # Try to use a font, fall back to default if not available
    try:
        font_size = int(size * 0.6)
        font = ImageFont.truetype("arial.ttf", font_size)
    except:
        font = ImageFont.load_default()

    # Draw mathematical symbol (Sigma Σ)
    text = "Σ"

    # Get text bounding box for centering
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]

    # Calculate position to center text
    x = (size - text_width) // 2
    y = (size - text_height) // 2 - bbox[1]

    # Draw text in white
    draw.text((x, y), text, fill='white', font=font)

    # Save image
    img.save(filename, 'PNG')
    print(f"Created {filename}")

# Create all three icon sizes
create_icon(16, 'C:/Users/cheri/moodle-mathjax-extension/icon16.png')
create_icon(48, 'C:/Users/cheri/moodle-mathjax-extension/icon48.png')
create_icon(128, 'C:/Users/cheri/moodle-mathjax-extension/icon128.png')

print("\nAll icons created successfully!")
