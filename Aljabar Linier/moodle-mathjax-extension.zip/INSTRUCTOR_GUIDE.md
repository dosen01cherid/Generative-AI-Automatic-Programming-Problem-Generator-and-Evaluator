# Instructor Guide - Distributing the Extension

## Before Distribution

### 1. Customize Moodle URL Matching

Edit `manifest.json` and update the `matches` array to match your specific Moodle site:

```json
"matches": [
  "https://your-school.moodle.com/*",
  "https://lms.yourschool.edu/*"
]
```

Current settings match common Moodle URLs, but being specific improves security.

### 2. Create Icons (Optional)

The extension needs three icon sizes. You can:
- Use placeholder icons (provided below)
- Create custom icons with your school branding
- Use any PNG image and rename to: `icon16.png`, `icon48.png`, `icon128.png`

**Quick option:** Use a simple math symbol (∑, ∫, π) or use online icon generators.

If you don't have icons, comment out the icons sections in `manifest.json`:

```json
// "icons": {
//   "16": "icon16.png",
//   "48": "icon48.png",
//   "128": "icon128.png"
// },
```

### 3. Test the Extension

1. Load it on your own browser first
2. Visit your Moodle site
3. Test with sample math: `$x^2 + y^2 = z^2$`
4. Verify formulas render correctly

## Distribution Methods

### Method 1: ZIP File (Recommended for Classes)

1. **Package the extension:**
   ```
   - Right-click the moodle-mathjax-extension folder
   - Send to → Compressed (zipped) folder
   - Rename to: moodle-mathjax-extension.zip
   ```

2. **Distribute:**
   - Upload to your LMS/Google Classroom
   - Email to students
   - Share via Google Drive/OneDrive
   - Provide with the README.md instructions

3. **Provide clear instructions:**
   - Share the README.md or create a video walkthrough
   - Common student issue: forgetting to enable Developer Mode

### Method 2: Chrome Web Store (For Long-term Use)

**Pros:** One-click install for students, no Developer Mode needed
**Cons:** $5 one-time developer fee, review process takes a few days

**Steps:**
1. Create a Chrome Web Store developer account
2. Pay $5 registration fee
3. Zip the extension folder
4. Upload to Chrome Web Store
5. Fill out listing details
6. Wait for review (1-3 days)
7. Share the store link with students

### Method 3: Enterprise Distribution (For IT Departments)

If your school has IT support, they can push the extension to all student computers automatically using Chrome Enterprise policies.

## Student Support

### Common Issues & Solutions

**"It's not working"**
- Did they enable Developer Mode?
- Did they refresh the Moodle page after installing?
- Are they on the correct Moodle site?

**"I don't see the extension"**
- Check chrome://extensions/ to verify it's enabled
- Try restarting the browser
- Reinstall the extension

**"Math still not rendering"**
- Check browser console (F12) for errors
- Verify the Moodle page actually contains math notation
- Try different math formats: `$...$`, `$$...$$`, `\(...\)`

### Quick Test for Students

Tell students to add this to any Moodle page's text editor:
```
Test: $x^2 + y^2 = z^2$ and $$\int_0^1 x dx = \frac{1}{2}$$
```

If they see formatted equations, it works!

## Updating the Extension

When you need to push updates:

1. Update the files
2. Increment the version in `manifest.json` (e.g., 1.0 → 1.1)
3. Re-distribute the new ZIP
4. Students remove old version and install new one

## Advanced Customization

### Change MathJax Delimiters

Edit `content.js` to change which symbols trigger math rendering:

```javascript
inlineMath: [['$', '$'], ['\\(', '\\)']],  // Current
displayMath: [['$$', '$$'], ['\\[', '\\]']],  // Current
```

### Add Custom MathJax Configuration

In `content.js`, modify the `window.MathJax` object to add packages, macros, etc.

### Disable Auto-Refresh on Content Changes

If the observer causes issues, comment out the MutationObserver section in `content.js`.

## Legal/Privacy Notes

This extension:
- Does NOT collect any data
- Does NOT track students
- Only injects MathJax library from CDN
- Only runs on Moodle pages (as specified in manifest)
- Is open source and auditable

Make sure this complies with your school's policies before distribution.
